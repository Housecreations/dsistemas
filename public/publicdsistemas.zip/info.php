<?php 
  echo phpinfo();